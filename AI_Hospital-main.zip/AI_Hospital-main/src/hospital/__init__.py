from .consultation import Consultation
from .collaborative_consultation import CollaborativeConsultation


__all__ = [
    "Consultation",
    "CollaborativeConsultation",
]
